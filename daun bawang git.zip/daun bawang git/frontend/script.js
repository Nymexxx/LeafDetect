
const API_URL = "http://192.168.1.190:8000";
const $ = (id) => document.getElementById(id);

const imageInput = $("imageInput");
const dropZone = $("dropZone");
const previewImage = $("previewImage");
const camera = $("camera");
const analyzeButton = $("analyzeButton");
const startCamera = $("startCamera");
const captureButton = $("captureButton");

let selectedFile = null;
let cameraStream = null;
let liveActive = false;
let analyzing = false;
let liveTimer = null;
let previewUrl = null;
let lastResultSignature = "";
let historyItems = [];

const diseaseInfo = {
    "bercak ungu": {
        scientific: "Alternaria porri",
        description: "Prediksi model menunjukkan kelas bercak ungu. Konfirmasikan gejala secara langsung karena penyakit lain dapat memiliki tampilan yang mirip.",
        advice: "Periksa pola bercak dan perkembangan gejala. Konsultasikan penanganan dengan petugas pertanian."
    },
    "embun bulu": {
        scientific: "Peronospora destructor",
        description: "Prediksi model menunjukkan kelas embun bulu. Periksa daun dan kondisi tanaman untuk memastikan gejala yang terlihat.",
        advice: "Perhatikan kelembapan, perubahan warna, dan perkembangan gejala. Jangan menyimpulkan penyakit dari satu foto saja."
    },
    "hawar daun": {
        scientific: "Penyebab perlu dikonfirmasi",
        description: "Hawar daun merupakan istilah gejala yang dapat disebabkan oleh beberapa faktor. Penyebab pastinya memerlukan pemeriksaan lebih lanjut.",
        advice: "Periksa pola kerusakan daun dan konsultasikan dengan petugas pertanian."
    },
    "moler": {
        scientific: "Fusarium spp.",
        description: "Prediksi model menunjukkan kelas moler. Pemeriksaan bagian pangkal dan akar dapat membantu memastikan diagnosis.",
        advice: "Periksa pangkal dan akar tanaman serta kondisi drainase."
    },
    "sehat": {
        scientific: "Tidak terindikasi penyakit oleh model",
        description: "Model mengklasifikasikan gambar sebagai sehat. Hasil ini tidak menjamin tanaman bebas dari semua penyakit.",
        advice: "Pantau kondisi tanaman secara berkala."
    }
};

function setApiStatus(online, message) {
    $("apiStatus").textContent = message;
    $("apiDot").className = `dot ${online ? "online" : "offline"}`;
}

async function checkApi() {
    try {
        const response = await fetch(`${API_URL}/health`);
        if (!response.ok) throw new Error("API tidak merespons");
        setApiStatus(true, "API terhubung");
    } catch (error) {
        setApiStatus(false, "API tidak terhubung");
        console.warn(error);
    }
}

function showError(message) {
    $("errorMessage").textContent = message;
    $("errorMessage").hidden = false;
}

function hideError() {
    $("errorMessage").hidden = true;
    $("errorMessage").textContent = "";
}

function setSelectedImage(file) {
    if (!file) return;

    hideError();

    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
        showError("Pilih gambar JPG, PNG, atau WEBP.");
        return;
    }

    if (file.size > 10 * 1024 * 1024) {
        showError("Ukuran gambar maksimal 10 MB.");
        return;
    }

    selectedFile = file;

    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = URL.createObjectURL(file);

    previewImage.src = previewUrl;
    previewImage.hidden = false;
    $("uploadPlaceholder").hidden = true;
    $("fileName").textContent = file.name;
    analyzeButton.disabled = false;
}

$("chooseImage").addEventListener("click", () => imageInput.click());

dropZone.addEventListener("click", (event) => {
    if (!event.target.closest("button")) imageInput.click();
});

dropZone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        imageInput.click();
    }
});

imageInput.addEventListener("change", () => {
    if (imageInput.files[0]) setSelectedImage(imageInput.files[0]);
});

["dragenter", "dragover"].forEach((name) => {
    dropZone.addEventListener(name, (event) => {
        event.preventDefault();
        dropZone.classList.add("dragging");
    });
});

["dragleave", "drop"].forEach((name) => {
    dropZone.addEventListener(name, (event) => {
        event.preventDefault();
        dropZone.classList.remove("dragging");
    });
});

dropZone.addEventListener("drop", (event) => {
    const file = event.dataTransfer.files[0];
    if (file) setSelectedImage(file);
});

$("clearButton").addEventListener("click", () => {
    selectedFile = null;
    imageInput.value = "";

    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null;

    previewImage.removeAttribute("src");
    previewImage.hidden = true;
    $("uploadPlaceholder").hidden = false;
    $("fileName").textContent = "Belum ada gambar dipilih";
    analyzeButton.disabled = true;

    $("resultContent").hidden = true;
    $("resultEmpty").hidden = false;
    $("resultBadge").textContent = "MENUNGGU";
    hideError();
});

// Mengirim gambar ke backend FastAPI
async function requestDetection(blob, filename) {
    const formData = new FormData();
    formData.append("file", blob, filename);

    const response = await fetch(`${API_URL}/detect`, {
        method: "POST",
        body: formData
    });

    if (!response.ok) {
        let detail = "";
        try {
            const data = await response.json();
            detail = data.detail || data.message || "";
        } catch (_) { }

        throw new Error(detail || `Backend merespons ${response.status}`);
    }

    const result = await response.json();

    if (result.status && result.status !== "success") {
        throw new Error(result.message || "Analisis gagal.");
    }

    return result;
}

function getConfidence(result) {
    const provided = Number(result.confidence_percent);

    if (
        result.confidence_percent !== undefined &&
        result.confidence_percent !== null &&
        Number.isFinite(provided)
    ) {
        return Math.max(0, Math.min(100, provided));
    }

    const raw = Number(result.confidence);
    return Math.max(0, Math.min(100, Number.isFinite(raw) ? raw * 100 : 0));
}

async function analyzeImage(file) {
    if (!file || analyzing) return;

    analyzing = true;
    analyzeButton.disabled = true;
    hideError();

    $("loadingState").hidden = false;
    $("resultEmpty").hidden = true;
    $("resultContent").hidden = true;
    $("resultBadge").textContent = "MEMPROSES";

    try {
        const result = await requestDetection(file, file.name || "daun.jpg");
        await renderResult(result, file);
        $("resultBadge").textContent = "SELESAI";
        setApiStatus(true, "API terhubung");
        await saveHistory(result, file);
    } catch (error) {
        console.error("Analisis gambar gagal:", error);
        $("resultBadge").textContent = "GAGAL";
        $("resultEmpty").hidden = false;
        showError(`Analisis gagal: ${error.message}`);
        setApiStatus(false, "Periksa koneksi API");
    } finally {
        analyzing = false;
        $("loadingState").hidden = true;
        analyzeButton.disabled = !selectedFile;
    }
}

analyzeButton.addEventListener("click", () => {
    if (selectedFile) analyzeImage(selectedFile);
});

async function renderResult(result, blob) {
    const disease = String(result.disease || "Tidak diketahui");
    const confidence = getConfidence(result);
    const info = diseaseInfo[disease.toLowerCase().trim()];

    $("disease").textContent = disease;
    $("confidence").textContent = `${confidence.toFixed(2)}%`;
    $("confidenceBar").style.width = `${confidence}%`;

    $("scientificName").textContent = info
        ? info.scientific
        : "Nama ilmiah perlu dikonfirmasi";

    $("description").textContent = info
        ? info.description
        : "Hasil merupakan prediksi model dan perlu diperiksa secara langsung.";

    $("advice").textContent = info
        ? info.advice
        : "Periksa tanaman dan konsultasikan hasil dengan petugas pertanian.";

    $("confidenceNote").textContent =
        "Skor kepercayaan model, bukan jaminan diagnosis benar.";

    const resultImage = $("resultImage");
    const objectUrl = URL.createObjectURL(blob);
    resultImage.onload = () => URL.revokeObjectURL(objectUrl);
    resultImage.onerror = () => URL.revokeObjectURL(objectUrl);
    resultImage.src = objectUrl;

    renderPredictions(result.predictions || { [disease]: confidence / 100 });

    $("resultEmpty").hidden = true;
    $("resultContent").hidden = false;
    $("loadingState").hidden = true;
}

function renderPredictions(predictions) {
    const container = $("allPredictions");
    container.replaceChildren();

    const entries = Object.entries(predictions)
        .map(([name, value]) => {
            let percent = Number(value);
            if (!Number.isFinite(percent)) percent = 0;
            if (percent <= 1) percent *= 100;
            return { name, percent: Math.max(0, Math.min(100, percent)) };
        })
        .sort((a, b) => b.percent - a.percent);

    for (const item of entries) {
        const row = document.createElement("div");
        row.className = "prediction-row";

        const name = document.createElement("span");
        name.textContent = item.name;

        const score = document.createElement("b");
        score.textContent = `${item.percent.toFixed(2)}%`;

        const track = document.createElement("div");
        track.className = "prediction-track";

        const bar = document.createElement("span");
        bar.style.width = `${item.percent}%`;

        track.appendChild(bar);
        row.append(name, score, track);
        container.appendChild(row);
    }
}

// KAMERA
startCamera.addEventListener("click", async () => {
    if (cameraStream) {
        stopCamera();
        return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
        $("cameraMessage").textContent =
            "Kamera tidak didukung browser ini atau halaman tidak menggunakan koneksi aman.";
        return;
    }

    try {
        startCamera.disabled = true;
        cameraStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: "environment" } },
            audio: false
        });

        camera.srcObject = cameraStream;
        camera.hidden = false;
        await camera.play();

        $("cameraPlaceholder").hidden = true;
        $("liveBadge").hidden = false;
        $("cameraStatus").textContent = "Aktif";
        $("cameraMessage").textContent =
            "Deteksi otomatis aktif. Arahkan kamera ke daun bawang.";
        startCamera.textContent = "Matikan Kamera";
        captureButton.disabled = false;

        liveActive = true;
        lastResultSignature = "";
        runLiveDetection();
    } catch (error) {
        console.error("Kamera gagal dibuka:", error);

        $("cameraMessage").textContent =
            "Kamera gagal: " + error.name + " - " + error.message;

        stopCamera();
    } finally {
        startCamera.disabled = false;
    }
});

function stopCamera() {
    liveActive = false;

    if (liveTimer) {
        clearTimeout(liveTimer);
        liveTimer = null;
    }

    if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
    }

    cameraStream = null;
    camera.srcObject = null;
    camera.hidden = true;

    $("cameraPlaceholder").hidden = false;
    $("liveBadge").hidden = true;
    $("cameraStatus").textContent = "Tidak aktif";
    $("cameraMessage").textContent = "Kamera tidak aktif.";
    startCamera.textContent = "◉ Nyalakan Kamera";
    captureButton.disabled = true;
}

async function runLiveDetection() {
    if (!liveActive || !cameraStream || analyzing) return;

    let frameBlob = null;

    try {
        if (camera.readyState < 2 || !camera.videoWidth) {
            scheduleNextFrame();
            return;
        }

        const canvas = document.createElement("canvas");
        canvas.width = camera.videoWidth;
        canvas.height = camera.videoHeight;

        const context = canvas.getContext("2d");
        context.drawImage(camera, 0, 0);

        frameBlob = await new Promise((resolve) => {
            canvas.toBlob(resolve, "image/jpeg", 0.8);
        });

        if (!frameBlob || !liveActive) return;

        analyzing = true;
        $("cameraMessage").textContent = "Menganalisis cuplikan kamera...";
        $("resultBadge").textContent = "REAL-TIME";

        const result = await requestDetection(frameBlob, "kamera-live.jpg");

        if (!liveActive) return;

        await renderResult(result, frameBlob);

        const signature = `${result.disease}:${getConfidence(result).toFixed(1)}`;

        if (signature !== lastResultSignature) {
            lastResultSignature = signature;
            $("cameraMessage").textContent =
                `Prediksi terbaru: ${result.disease}. Analisis otomatis aktif.`;
        } else {
            $("cameraMessage").textContent =
                `Kamera aktif · Prediksi terbaru: ${result.disease}`;
        }

        $("cameraStatus").textContent = "Aktif";
        $("resultBadge").textContent = "REAL-TIME";
        setApiStatus(true, "API terhubung");

    } catch (error) {
        if (liveActive) {
            console.error("Deteksi kamera gagal:", error);
            $("cameraMessage").textContent =
                `Analisis gagal: ${error.message}. Mencoba kembali...`;
            setApiStatus(false, "Periksa koneksi API");
        }
    } finally {
        analyzing = false;

        if (liveActive) scheduleNextFrame();
    }
}

function scheduleNextFrame() {
    if (!liveActive) return;

    const interval = Number($("intervalSelect").value) || 2500;
    liveTimer = setTimeout(runLiveDetection, interval);
}

// Ambil foto saat kamera aktif dan jalankan analisis langsung.
captureButton.addEventListener("click", async () => {
    if (!cameraStream || !camera.videoWidth || analyzing) return;

    const canvas = document.createElement("canvas");
    canvas.width = camera.videoWidth;
    canvas.height = camera.videoHeight;
    canvas.getContext("2d").drawImage(camera, 0, 0);

    canvas.toBlob(async (blob) => {
        if (!blob) {
            showError("Gagal mengambil foto dari kamera.");
            return;
        }

        const file = new File([blob], "foto-daun.jpg", { type: "image/jpeg" });
        setSelectedImage(file);
        await analyzeImage(file);
    }, "image/jpeg", 0.9);
});

// Riwayat deteksi disimpan secara lokal di browser.
function fileToDataURL(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("Gagal membaca gambar"));
        reader.readAsDataURL(file);
    });
}

async function saveHistory(result, file) {
    try {
        const image = await fileToDataURL(file);

        historyItems.unshift({
            disease: String(result.disease || "Tidak diketahui"),
            confidence: getConfidence(result),
            image,
            date: new Date().toLocaleString("id-ID")
        });

        historyItems = historyItems.slice(0, 12);

        try {
            localStorage.setItem("leafdetect-history", JSON.stringify(historyItems));
        } catch (error) {
            console.warn("Penyimpanan riwayat gagal:", error);
        }

        renderHistory();
    } catch (error) {
        console.warn("Riwayat tidak dapat dibuat:", error);
    }
}

function renderHistory() {
    const container = $("historyList");
    container.replaceChildren();

    if (!historyItems.length) {
        const empty = document.createElement("p");
        empty.className = "muted";
        empty.textContent = "Belum ada riwayat deteksi.";
        container.appendChild(empty);
        return;
    }

    historyItems.forEach((item) => {
        const card = document.createElement("article");
        card.className = "history-card";

        const image = document.createElement("img");
        image.src = item.image;
        image.alt = "Foto riwayat deteksi";
        image.loading = "lazy";

        const content = document.createElement("div");
        content.className = "history-card-content";

        const name = document.createElement("b");
        name.textContent = item.disease;

        const score = document.createElement("p");
        score.textContent = `Kepercayaan: ${Number(item.confidence).toFixed(2)}%`;

        const date = document.createElement("p");
        date.textContent = item.date;

        content.append(name, score, date);
        card.append(image, content);
        container.appendChild(card);
    });
}


$("clearHistory").addEventListener("click", () => {
    // Jangan lakukan apa-apa jika history kosong
    if (!historyItems || historyItems.length === 0) {
        return;
    }

    showDeleteModal(() => {
        historyItems = [];
        localStorage.removeItem("leafdetect-history");
        renderHistory();
    });

    const clearButton = $("clearHistory");

    if (clearButton) {
        const isEmpty = !historyItems || historyItems.length === 0;

        clearButton.disabled = isEmpty;
        clearButton.style.opacity = isEmpty ? "0.5" : "1";
        clearButton.style.cursor = isEmpty ? "not-allowed" : "pointer";
    }
});


// Tema gelap
$("themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("dark-theme");
    const dark = document.body.classList.contains("dark-theme");
    $("themeToggle").textContent = dark ? "☀ Tema" : "☼ Tema";

    try {
        localStorage.setItem("leafdetect-dark-theme", dark ? "yes" : "no");
    } catch (_) { }
});

try {
    if (localStorage.getItem("leafdetect-dark-theme") === "yes") {
        document.body.classList.add("dark-theme");
        $("themeToggle").textContent = "☀ Tema";
    }

    const saved = localStorage.getItem("leafdetect-history");
    if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) historyItems = parsed;
    }
} catch (error) {
    console.warn("Data browser tidak dapat dibaca:", error);
}

renderHistory();
checkApi();

// ===== DELETE HISTORY MODAL =====

const deleteModal = document.getElementById("deleteModal");
const cancelDeleteBtn = document.getElementById("cancelDelete");
const confirmDeleteBtn = document.getElementById("confirmDelete");

let deleteAction = null;

function showDeleteModal(action, options = {}) {
    if (!deleteModal) return;

    deleteAction = action;

    document.getElementById("deleteModalTitle").textContent =
        options.title || "Hapus riwayat deteksi?";

    document.getElementById("deleteModalMessage").textContent =
        options.message ||
        "Apakah kamu yakin ingin menghapus seluruh riwayat deteksi? Tindakan ini tidak dapat dibatalkan.";

    confirmDeleteBtn.querySelector("span").textContent =
        options.confirmText || "Ya, Hapus";

    deleteModal.classList.add("show");
    document.body.style.overflow = "hidden";

    cancelDeleteBtn.focus();
}

function hideDeleteModal() {
    if (!deleteModal) return;

    deleteModal.classList.remove("show");
    document.body.style.overflow = "";
    deleteAction = null;
}

cancelDeleteBtn?.addEventListener("click", hideDeleteModal);

deleteModal?.addEventListener("click", (event) => {
    if (event.target === deleteModal) {
        hideDeleteModal();
    }
});

confirmDeleteBtn?.addEventListener("click", () => {
    const action = deleteAction;

    hideDeleteModal();

    if (typeof action === "function") {
        action();
    }
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && deleteModal?.classList.contains("show")) {
        hideDeleteModal();
    }
});