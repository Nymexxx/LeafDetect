
import json
from pathlib import Path

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# ==========================================
# KONFIGURASI PROYEK DAUNAI
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

DATASET_DIR = Path(
    r"C:\Users\HP\Downloads\onion disease leaf.v1i.folder"
)

MODEL_DIR = BASE_DIR / "backend" / "models"
MODEL_PATH = MODEL_DIR / "daunai_mobilenetv2.keras"
CLASS_PATH = MODEL_DIR / "class_names.json"

IMAGE_SIZE = (224, 224)
BATCH_SIZE = 16
EPOCHS = 12
SEED = 42

CLASS_NAMES = [
    "bercak ungu",
    "embun bulu",
    "hawar daun",
    "moler",
    "sehat",
]

# ==========================================
# PERSIAPAN
# ==========================================

def main():
    print("=" * 50)
    print("TRAINING MODEL DAUNAI")
    print("=" * 50)

    if not DATASET_DIR.is_dir():
        raise FileNotFoundError(
            f"Folder dataset tidak ditemukan: {DATASET_DIR}"
        )

    for split in ["train", "valid", "test"]:
        split_path = DATASET_DIR / split
        if not split_path.is_dir():
            raise FileNotFoundError(
                f"Folder tidak ditemukan: {split_path}"
            )

        for class_name in CLASS_NAMES:
            if not (split_path / class_name).is_dir():
                raise FileNotFoundError(
                    f"Folder kelas tidak ditemukan: "
                    f"{split_path / class_name}"
                )

    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    print("TensorFlow:", tf.__version__)
    print("Dataset:", DATASET_DIR)
    print("Kelas:", CLASS_NAMES)

    # ==========================================
    # MEMUAT DATASET
    # ==========================================

    print("\nMemuat dataset training...")

    train_ds = keras.utils.image_dataset_from_directory(
        DATASET_DIR / "train",
        class_names=CLASS_NAMES,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        shuffle=True,
        seed=SEED,
        label_mode="int",
    )

    valid_ds = keras.utils.image_dataset_from_directory(
        DATASET_DIR / "valid",
        class_names=CLASS_NAMES,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        shuffle=False,
        label_mode="int",
    )

    test_ds = keras.utils.image_dataset_from_directory(
        DATASET_DIR / "test",
        class_names=CLASS_NAMES,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        shuffle=False,
        label_mode="int",
    )

    print("\nUrutan label kelas:")
    for index, name in enumerate(CLASS_NAMES):
        print(f"{index}: {name}")

    # MobileNetV2 membutuhkan preprocessing khusus.
    def preprocess(images, labels):
        images = keras.applications.mobilenet_v2.preprocess_input(
            tf.cast(images, tf.float32)
        )
        return images, labels

    train_ds = train_ds.map(
        preprocess, num_parallel_calls=tf.data.AUTOTUNE
    ).prefetch(tf.data.AUTOTUNE)

    valid_ds = valid_ds.map(
        preprocess, num_parallel_calls=tf.data.AUTOTUNE
    ).prefetch(tf.data.AUTOTUNE)

    test_ds = test_ds.map(
        preprocess, num_parallel_calls=tf.data.AUTOTUNE
    ).prefetch(tf.data.AUTOTUNE)

    # ==========================================
    # MEMBANGUN MODEL MOBILENETV2
    # ==========================================

    print("\nMemuat MobileNetV2...")

    base_model = keras.applications.MobileNetV2(
        input_shape=(*IMAGE_SIZE, 3),
        include_top=False,
        weights="imagenet",
    )

    # Tahap pertama: bekukan backbone pretrained.
    base_model.trainable = False

    inputs = keras.Input(shape=(*IMAGE_SIZE, 3))

    x = base_model(inputs, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.25)(x)
    outputs = layers.Dense(
        len(CLASS_NAMES),
        activation="softmax",
        name="predictions",
    )(x)

    model = keras.Model(inputs, outputs)

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    model.summary()

    # ==========================================
    # TRAINING
    # ==========================================

    callbacks = [
        keras.callbacks.ModelCheckpoint(
            filepath=str(MODEL_PATH),
            monitor="val_loss",
            save_best_only=True,
            verbose=1,
        ),
        keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=4,
            restore_best_weights=True,
            verbose=1,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=2,
            min_lr=1e-6,
            verbose=1,
        ),
    ]

    print("\nMulai training...")

    history = model.fit(
        train_ds,
        validation_data=valid_ds,
        epochs=EPOCHS,
        callbacks=callbacks,
    )

    # ==========================================
    # EVALUASI DATA TEST
    # ==========================================

    print("\nMemuat model terbaik...")

    best_model = keras.models.load_model(MODEL_PATH)

    print("\nEvaluasi menggunakan dataset test:")

    test_loss, test_accuracy = best_model.evaluate(
        test_ds, verbose=1
    )

    print(f"\nTest loss     : {test_loss:.4f}")
    print(f"Test accuracy : {test_accuracy * 100:.2f}%")

    # Simpan urutan label agar backend tidak salah
    # menerjemahkan indeks prediksi menjadi nama kelas.
    with open(CLASS_PATH, "w", encoding="utf-8") as file:
        json.dump(
            CLASS_NAMES,
            file,
            ensure_ascii=False,
            indent=4,
        )

    print("\nTraining selesai.")
    print(f"Model tersimpan: {MODEL_PATH}")
    print(f"Label tersimpan: {CLASS_PATH}")
    print("Catatan: akurasi test bukan jaminan akurasi")
    print("pada kondisi kamera dan lapangan sebenarnya.")


if __name__ == "__main__":
    main()
